#!/bin/bash

./halite -d "30 30" "java -cp v3 MyBot" "java MyBot"
