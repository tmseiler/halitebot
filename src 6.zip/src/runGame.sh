#!/bin/bash

./halite -d "30 30" "java -cp ~/projects/halitebot/v5 MyBot" "java MyBot"
