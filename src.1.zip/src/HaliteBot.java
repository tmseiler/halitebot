import java.util.ArrayList;

class HaliteBot {
    private int myID;
    private GameMap gameMap;


    void run() {
        InitPackage iPackage = Networking.getInit();
        myID = iPackage.myID;
        gameMap = iPackage.map;

        Networking.sendInit("MyJavaBot");

        while(true) {
            ArrayList<Move> moves = new ArrayList<Move>();

            gameMap = Networking.getFrame();

            for(int y = 0; y < gameMap.height; y++) {
                for(int x = 0; x < gameMap.width; x++) {
                    Location loc = new Location(x, y);
                    Site site = gameMap.getSite(loc);
                    Move move;

                    if(isFriendly(site)) {
                        Direction dir = findWeakestEnemy(loc);
                        if(dir == null && site.strength > site.production * 3) {
                            move = new Move(loc, Direction.NORTH);
                        } else if (site.strength > gameMap.getSite(loc, dir).strength) {
                            move = new Move(loc, dir);
                        } else {
                            move = new Move(loc, Direction.STILL);
                        }
                        moves.add(move);
                    }
                }
            }
            Networking.sendFrame(moves);
        }
    }

    private Direction findWeakestEnemy(Location loc) {
        int weakestStr = Halite.MAX_STRENGTH;
        Direction weakestDirection = null;
        for (Direction d : Direction.CARDINALS) {
            Site checkSite = gameMap.getSite(loc, d);
            if(!isFriendly(checkSite) && checkSite.strength < weakestStr) {
                weakestDirection = d;
            }
        }
        return weakestDirection;
    }

    private boolean isFriendly(Site site) {
        return site.owner == myID;
    }
}
