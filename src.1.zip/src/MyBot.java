public class MyBot {
    public static void main(String[] args) throws java.io.IOException {
        new HaliteBot().run();
    }
}
