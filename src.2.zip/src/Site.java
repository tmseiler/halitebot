class Site {
    int owner, strength, production;

    double strengthProductionIndex, bolsterScore;

    double getStrengthProductionIndex() {
        strengthProductionIndex = (float) production / (float) strength;
        return strengthProductionIndex;
    }
}
