public class Halite {
    static int MAX_STRENGTH = 255;
}
